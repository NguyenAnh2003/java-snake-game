package client;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.Timer;

import java.awt.*;
import java.awt.event.*;
import java.io.BufferedWriter;
import java.io.File;
import java.io.ObjectOutputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.*;

public class GamePanel extends JPanel implements ActionListener {

  Socket socket;
  static final int SCREEN_WIDTH = 600;
  static final int SCREEN_HEIGHT = 600;
  static final int UNIT_SIZE = 25;
  static final int GAME_UNITS = (SCREEN_WIDTH * SCREEN_HEIGHT) / UNIT_SIZE;
  static final int DELAY = 75;
  final int PORT = 12345;
  final int x[] = new int[GAME_UNITS];
  final int y[] = new int[GAME_UNITS];
  int bodyParts = 5;
  int applesEaten; // point
  int appleX;
  int appleY;
  char direction = 'R';
  boolean running;
  Timer timer;
  Random random;
  String username = "";
  int tempx, tempy;
  int i;
  public GamePanel(String name) {
    try {
      this.username = name;
      random = new Random();
      this.setPreferredSize(new Dimension(SCREEN_WIDTH, SCREEN_HEIGHT));
      this.setBackground(Color.BLACK);
      this.setFocusable(true);
      this.addKeyListener(new MyKeyAdapter());
      startGame();
    } catch (Exception e) {
      //TODO: handle exception
      e.printStackTrace();
    }
  }

  public void startGame() {
    newApple();
    running = true;
    timer = new Timer(DELAY, this);
    timer.start();
  }

  public void paintComponent(Graphics g) {
    super.paintComponent(g);
    draw(g);
  }

  public void draw(Graphics g) {
    if (running) {
      // for (int i = 0; i < SCREEN_HEIGHT / UNIT_SIZE; i++) {
      //   g.drawLine(i * UNIT_SIZE, 0, i * UNIT_SIZE, SCREEN_HEIGHT);
      //   g.drawLine(0, i * UNIT_SIZE, SCREEN_WIDTH, i * UNIT_SIZE);
      // } 

      // draw apple
      // g.setColor(Color.RED);
      ImageIcon appleIcon = new ImageIcon("D:\\JAVA\\client\\apple.png"); 
      Image dabImg = appleIcon.getImage();
      Image modified = dabImg.getScaledInstance(32, 32, Image.SCALE_SMOOTH);
      appleIcon = new ImageIcon(modified);
      appleIcon.paintIcon(this, g, appleX, appleY);
      // g.fillRect(appleX, appleY, UNIT_SIZE, UNIT_SIZE);

      // body increasing body part 
      for (i = 0; i < bodyParts; i++) {
        if (i == 0) {
          g.setColor(Color.WHITE);
          g.fillRect(x[i], y[i], UNIT_SIZE, UNIT_SIZE);
        } else {
          g.setColor(Color.WHITE);
          g.fillRect(x[i], y[i], UNIT_SIZE, UNIT_SIZE);
        }
      }

      g.setColor(Color.WHITE);
      g.setFont(new Font(null, Font.BOLD, 25));
      FontMetrics metrics = getFontMetrics(g.getFont());
      g.drawString("Score: " + applesEaten, (SCREEN_WIDTH - metrics.stringWidth("Score:" + applesEaten)) / (SCREEN_WIDTH-1),
      g.getFont().getSize());
      
    } else {
      gameOver(g);
    }
  }

  public void newApple() {
    appleX = random.nextInt((int) (SCREEN_WIDTH / UNIT_SIZE)) * UNIT_SIZE;
    appleY = random.nextInt((int) (SCREEN_HEIGHT / UNIT_SIZE)) * UNIT_SIZE;
  }

  public void move() {
    for (int i = bodyParts; i > 0; i--) {
      x[i] = x[i - 1];
      y[i] = y[i - 1];
    }
    switch (direction) {
      case 'U':
        y[0] = y[0] - UNIT_SIZE;
        break;
      case 'D':
        y[0] = y[0] + UNIT_SIZE;
        break;
      case 'L':
        x[0] = x[0] - UNIT_SIZE;
        break;
      case 'R':
        x[0] = x[0] + UNIT_SIZE;
        break;
    }
  }

  public void checkApple() {
    if ((x[0] == appleX) && (y[0] == appleY)) {
      bodyParts++;
      applesEaten++;
      soundLvlUp();
      newApple();
    }
  }

  public void checkCollision() {
    // check if head collides with body
    for (int i = bodyParts; i > 0; i--) {
      if ((x[0] == x[i]) && (y[0] == y[i])) {
        running = false;
      }
    }
    // check if head touches left boder
    if (x[0] < 0) {
      running = false;
    }
    // check if head touches right boder
    if (x[0] > SCREEN_WIDTH) {
      running = false;
    }
    // check if head touches top
    if (y[0] < 0) {
      running = false;
    }
    // check bottom
    if (y[0] > SCREEN_HEIGHT) {
      running = false;
    }
    if (!running) {
      timer.stop();
    }
  }

  public void sendToServer() {
    try {
      socket = new Socket("localhost", PORT);
      ArrayList<String> list = new ArrayList<String>();
      list.add("update");
      list.add(this.username);
      list.add(Integer.toString(applesEaten));
      ObjectOutputStream objectOutput = new ObjectOutputStream(socket.getOutputStream());
      objectOutput.writeObject(list);
      objectOutput.flush();
    } catch (Exception e) {
      //TODO: handle exception
      e.printStackTrace();
    }
  }

  public void gameOver(Graphics g) {
    GameOverSound();
    g.setColor(Color.WHITE);
    g.setFont(new Font(null, Font.BOLD, 15));
    FontMetrics username = getFontMetrics(g.getFont());
    g.drawString("User: " + this.username, (SCREEN_WIDTH-username.stringWidth("User: " + this.username) - 20),g.getFont().getSize());
    g.setColor(Color.WHITE);
    g.setFont(new Font(null, Font.BOLD, 25));
    FontMetrics score = getFontMetrics(g.getFont());
    g.drawString("Score: " + applesEaten, (SCREEN_WIDTH - score.stringWidth("Score:" + applesEaten)) / 2,
    g.getFont().getSize());
    g.setColor(Color.RED);
    g.setFont(new Font(null, Font.BOLD, 75));
    FontMetrics metrics = getFontMetrics(g.getFont());
    g.drawString("Game Over", (SCREEN_WIDTH - metrics.stringWidth("Game Over")) / 2, SCREEN_HEIGHT / 2);
    g.setColor(Color.WHITE);
    g.setFont(new Font(null, Font.BOLD, 35));
    FontMetrics SaveP = getFontMetrics(g.getFont());
    g.drawString("Press E to Save point", (SCREEN_WIDTH - SaveP.stringWidth("Press S to Save point")) / 2, (int) (SCREEN_HEIGHT / 1.2));
  }

  // sound game level
  public void soundLvlUp() {
    try {
      File sound = new File("D:\\JAVA\\client\\sound_game_2.wav");
      AudioInputStream audio = AudioSystem.getAudioInputStream(sound);
      Clip clip = AudioSystem.getClip();
      clip.open(audio);
      clip.start();
    } catch (Exception e) {
      //TODO: handle exception
      e.printStackTrace();
    }
  }
  
  // game over sound
  public void GameOverSound() {
    try {
      File sound = new File("D:\\JAVA\\client\\game_over.wav");
      AudioInputStream audio = AudioSystem.getAudioInputStream(sound);
      Clip clip = AudioSystem.getClip();
      clip.open(audio);
      clip.start();
    } catch (Exception e) {
      //TODO: handle exception
      e.printStackTrace();
    }
  }

  
  @Override
  public void actionPerformed(ActionEvent e) {
    if (running) {
      move();
      checkApple();
      checkCollision();
    }
    repaint();
  }

  public class MyKeyAdapter extends KeyAdapter {
    @Override
    public void keyPressed(KeyEvent e) {
      if(e.getKeyCode() == KeyEvent.VK_SPACE)
      {
        running = true;
        repaint();
      }
      if(e.getKeyCode() == KeyEvent.VK_S) // stop
      {
        timer.stop();
      }
      if(e.getKeyCode() == KeyEvent.VK_C) // continue
      {
        timer.start();
      }
      if(e.getKeyCode() == KeyEvent.VK_E) // point to server for processing
      {
        sendToServer();
      }
      if(e.getKeyCode() == KeyEvent.VK_RIGHT)
      {
        if (direction != 'L') {
          direction = 'R';
        }
      }
      if(e.getKeyCode() == KeyEvent.VK_LEFT)
      {
        if (direction != 'R') {
          direction = 'L';
        }
      }
      if(e.getKeyCode() == KeyEvent.VK_UP)
      {
        if (direction != 'D') {
          direction = 'U';
        }
      }
      if(e.getKeyCode() == KeyEvent.VK_DOWN)
      {
        if (direction != 'U') {
          direction = 'D';
        }
      }
    }
  }
}
