package client;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.UnsupportedAudioFileException;

public class sound {
  public static void main(String[] args) {
    try {
      Scanner sc = new Scanner(System.in);
      File file = new File("D:\\JAVA\\client\\sound_game_1.wav");
      AudioInputStream audio = AudioSystem.getAudioInputStream(file);
      Clip clip = AudioSystem.getClip();
      clip.open(audio);
      // clip.start();
      String res = "";
      while(!res.equals("Q")) {
        res = sc.next();
        switch (res) {
          case "s":
            clip.start();
            break;
          default:
            break;
        }
      }
    } catch (Exception e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
    
  }
}
