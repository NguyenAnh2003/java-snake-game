package server.finalTerm;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class server {

  ServerSocket server;
  Socket socket;
  Connection conn;
  int pointRecieved;
  String nameReceived;
  String sql = "";
  PreparedStatement updatePoint;

  PreparedStatement selectPoint, checking;
  int point = 0, max = 0;

  // send name and point to server
  public server() {
    try {
      Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
      conn = DriverManager.getConnection(
          "jdbc:sqlserver://DESKTOP-PNPO69N\\SQLEXPRESS;databaseName=managementProject;user=sa;password=12345");
      server = new ServerSocket(12345);
      System.out.println("Waiting . . .");
      while (true) {
        socket = server.accept();
        if (socket.isConnected())
          System.out.println("Connected");
        receivedData(socket); //
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  // send file to client
  public void sendToClient(Socket socket) {
    try {
      innitXML();
      File fileToSent = new File("D:\\Project_Java\\Project\\src\\server\\finalTerm\\XMLsent.xml");
      FileInputStream fileInputStream = new FileInputStream(fileToSent);
      DataOutputStream dataOutputStream = new DataOutputStream(socket.getOutputStream());
      String fileName = fileToSent.toString();
      byte[] fileNameBytes = fileName.getBytes();
      byte[] fileContentBytes = new byte[(int) fileToSent.length()];
      fileInputStream.read(fileContentBytes);
      dataOutputStream.writeInt(fileNameBytes.length);
      dataOutputStream.write(fileNameBytes);
    } catch (Exception e) {
      // TODO: handle exception
      e.printStackTrace();
    }
  }

  // init XML file
  public void innitXML() {
    try {
      Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
      conn = DriverManager.getConnection(
          "jdbc:sqlserver://DESKTOP-PNPO69N\\SQLEXPRESS;databaseName=managementProject;user=sa;password=12345");
      sql = "select * from userPoint order by point desc";
      selectPoint = conn.prepareStatement(sql);
      ResultSet rs = selectPoint.executeQuery();
      DocumentBuilderFactory fac = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = fac.newDocumentBuilder();
      Document document = documentBuilder.newDocument();
      Element root = document.createElement("board");
      document.appendChild(root);
      while (rs.next()) {
        // member
        Element member = document.createElement("members");
        // name
        String name = rs.getString(2);
        Element nameTag = document.createElement("name");
        nameTag.setTextContent(name);
        member.appendChild(nameTag);
        // point
        int point = Integer.parseInt(rs.getString(3));
        Element pointTag = document.createElement("point");
        pointTag.setTextContent(Integer.toString(point));
        member.appendChild(pointTag);

        root.appendChild(member);

        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer = transformerFactory.newTransformer();
        DOMSource domSource = new DOMSource(document);
        StreamResult streamResult = new StreamResult(
            new File("D:\\Project_Java\\Project\\src\\server\\finalTerm\\XMLsent.xml"));
        transformer.setOutputProperty(OutputKeys.INDENT, "yes");
        transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "3");
        transformer.transform(domSource, streamResult);
      }
      System.out.println("XML created");
    } catch (Exception e) {
      // TODO: handle exception
      e.printStackTrace();
    }
  }

  // receive data from client
  public void receivedData(Socket socket) {
    try {
      ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
      ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
      Object object = in.readObject();
      ArrayList<String> listDta = (ArrayList<String>) object;
      String command = listDta.get(0);

      if (command.equals("update")) {
        innitXML();
        String username = listDta.get(1);
        int point = Integer.parseInt(listDta.get(2));
        System.out.println(username);
        System.out.println(point);
        updatePoint(username, point);
        System.out.println(command);
      }
      // show record 
      else if (command.equals("show")) {
        File fileToSent = new File("D:\\Project_Java\\Project\\src\\server\\finalTerm\\XMLsent.xml");
        FileInputStream fileInputStream = new FileInputStream(fileToSent);
        String fileName = fileToSent.toString();
        byte[] fileNameBytes = fileName.getBytes();
        byte[] fileContentBytes = new byte[(int) fileToSent.length()];
        fileInputStream.read(fileContentBytes);
        System.out.println(fileNameBytes.length);
        out.writeUTF(Integer.toString(fileNameBytes.length));
        out.write(fileNameBytes);
        out.writeUTF(Integer.toString(fileContentBytes.length));
        out.write(fileContentBytes);
        out.flush();
        System.out.println(command);
      }
      // check login 
      else if(command.equals("check"))
      {
        String username = listDta.get(1);
        String hash = listDta.get(2);
        System.err.println(username);
        System.out.println(hash);
        // System.out.println(command);
        sql = "select * from userHash where name = ? and password = ?";
        checking = conn.prepareStatement(sql);
        checking.setString(1, username);
        checking.setString(2, hash);
        ResultSet rs = checking.executeQuery();
        String mess = "";
        if(rs.next()){
          mess = "yes";
        }
        else {
          mess = "no";
        }
        out.writeObject(mess);
        out.flush();
      }
    } catch (Exception e) {
      // TODO: handle exception
      e.printStackTrace();
    }
  }

  // function compare point if point <= data in DB return nothing else update the
  // point the DB
  public void updatePoint(String name, int point) {
    try {
      if (point <= selectPoint(name))
        return; // compare point
      else {
        sql = "update userPoint set point = ? where name = ?";
        updatePoint = conn.prepareStatement(sql);
        updatePoint.setInt(1, point);
        updatePoint.setString(2, name);
        updatePoint.executeUpdate();
      }
    } catch (Exception e) {
      // TODO: handle exception
      e.printStackTrace();
    }
  }

  public int selectPointUser(String name) {
    int point = 0;
    try {
      sql = "select point from userPoint where name = ?";
      selectPoint = conn.prepareStatement(sql);
      selectPoint.setString(1, name);
      ResultSet rs = selectPoint.executeQuery();
      if (rs.next())
        point = Integer.parseInt(rs.getString(1));
    } catch (Exception e) {
      // TODO: handle exception
      System.out.println(e.getMessage());
    }
    return point;
  }

  public int selectPoint(String name) {
    try {
      sql = "select point from userPoint where name = ?";
      selectPoint = conn.prepareStatement(sql);
      selectPoint.setString(1, name);
      ResultSet rs = selectPoint.executeQuery();
      if (rs.next())
        point = Integer.parseInt(rs.getString(1));
    } catch (Exception e) {
      // TODO: handle exception
      e.printStackTrace();
    }
    return point;
  }

  public static void main(String[] args) {
    new server();
  }
}
