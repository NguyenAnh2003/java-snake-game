package client;

import java.awt.Color;
import java.awt.Font;
import java.io.File;

import javax.swing.*;
public class Table extends JFrame{

  JTable table;
  JScrollPane scrollPane;
  Model model;
  
  public Table(String file) {
    model = new Model(file);
    table = new JTable();
    table.setModel(model);
    table.setBackground(Color.BLACK);
    table.setForeground(Color.WHITE);
    table.setOpaque(true);
    table.setFont(new Font(null, Font.BOLD, 15));
    table.getTableHeader().setOpaque(true);
    table.getTableHeader().setFont(new Font(null, Font.BOLD, 15));
    table.getTableHeader().setBackground(Color.BLACK);
    table.getTableHeader().setForeground(Color.RED);
    table.setRowHeight(25);
    scrollPane = new JScrollPane(table);
    JPanel panel = new JPanel();
    panel.add(scrollPane);
    this.getContentPane().add(panel, "North");
    this.setResizable(false);
    this.setSize(500, 280);
    this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    this.setVisible(true);
  }

  public static void main(String[] args) {
    new Table("D:\\Project_Java\\Project\\src\\server\\finalTerm\\XMLsent.xml");
  }

}
