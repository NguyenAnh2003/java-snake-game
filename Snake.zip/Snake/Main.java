package client;

import java.util.ArrayList;
import java.util.Scanner;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.*;
import java.awt.*;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import Source.client;

import java.net.*;
import java.io.*;
import javax.sound.sampled.*;

public class Main extends Thread {

  Scanner scanner;
  Connection conn;
  PreparedStatement select;
  String sql = "";
  String username, hash;
  JLabel namelb, passlb;
  JTextField name;
  JPasswordField pass;
  JButton submit, cancel;
  JFrame frame;
  JLabel welcome;
  JLabel title;
  JLabel showPass;
  JButton start;
  String fileName;
  Socket s;
  File sound;
  final int PORT = 12345;

  public Main() {
    try {
      Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
      conn = DriverManager.getConnection(
          "jdbc:sqlserver://DESKTOP-PNPO69N\\SQLEXPRESS;databaseName=managementProject;user=sa;password=12345");
      frame = new JFrame();
      frame.getContentPane().setBackground(Color.BLACK);
      showPass = new JLabel("show password");
      showPass.setBounds(150, 350, 150, 25);
      showPass.setFont(new Font(null, Font.BOLD, 15));
      showPass.setForeground(Color.WHITE);
      showPass.setOpaque(true);
      showPass.addMouseListener(new MouseListener() {

        @Override
        public void mouseClicked(MouseEvent e) {
          // TODO Auto-generated method stub
        }

        @Override
        public void mousePressed(MouseEvent e) {
          // TODO Auto-generated method stub
          
        }

        @Override
        public void mouseReleased(MouseEvent e) {
          // TODO Auto-generated method stub
          
        }

        @Override
        public void mouseEntered(MouseEvent e) {
          // TODO Auto-generated method stub
          pass.setEchoChar((char)0);
        }

        @Override
        public void mouseExited(MouseEvent e) {
          // TODO Auto-generated method stub
          pass.setEchoChar('.');
        }
        
      });
      showPass.setBackground(new Color(0,0,0,0));
      title = new JLabel();
      title.setIcon(new ImageIcon("D:\\JAVA\\client\\Snake-Title.png"));
      title.setBounds(20, 20, 580, 150);
      namelb = new JLabel("Name");
      namelb.setForeground(Color.WHITE);
      namelb.setOpaque(true);
      namelb.setBackground(new Color(0,0,0,0));
      namelb.setBounds(20, 220, 120, 20);
      namelb.setFont(new Font(null, Font.BOLD, 25));
      passlb = new JLabel("Password");
      passlb.setBackground(new Color(0,0,0,0));
      passlb.setForeground(Color.WHITE);
      passlb.setOpaque(true);
      passlb.setBounds(20, 300, 120, 20);
      passlb.setFont(new Font(null, Font.BOLD, 25));
      name = new JTextField();
      name.setFont(new Font(null, Font.BOLD, 16));
      name.setForeground(Color.WHITE);
      name.setOpaque(true);
      name.setBackground(Color.BLACK);
      name.setBounds(150, 210, 450, 50);
      pass = new JPasswordField();
      pass.setFont(new Font(null, Font.BOLD, 16));
      pass.setForeground(Color.WHITE);
      pass.setOpaque(true);
      pass.setBackground(Color.BLACK);
      pass.setEchoChar('.');
      pass.setBounds(150, 290, 450, 50);
      pass.addKeyListener(new KeyAdapter() {
        public void keyPressed(KeyEvent event) {
          if (event.getKeyCode() == KeyEvent.VK_ENTER) {
            String username = name.getText();
            String hash = pass.getText();
            checkLogin(username, hash);
          }
        }
      });

      submit = new JButton("Submit");
      submit.setBounds(500, 350, 100, 50);
      submit.setForeground(Color.WHITE);
      submit.setFont(new Font(null, Font.BOLD, 20));
      submit.setOpaque(true);
      submit.setFocusable(false);
      submit.setBackground(Color.BLACK);
      submit.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
          // TODO Auto-generated method stub
          String username = name.getText();
          String hash = pass.getText();
          checkLogin(username, hash);
        }
      });
      submit.addMouseListener(new MouseListener(){

        @Override
        public void mouseClicked(MouseEvent e) {}

        @Override
        public void mousePressed(MouseEvent e) {}

        @Override
        public void mouseReleased(MouseEvent e) {}

        @Override
        public void mouseEntered(MouseEvent e) {
          // TODO Auto-generated method stub
          soundEffect();
        }

        @Override
        public void mouseExited(MouseEvent e) {}

      });

      welcome = new JLabel();
      welcome.setForeground(Color.WHITE);
      welcome.setOpaque(true);
      welcome.setBackground(new Color(0,0,0,0));
      welcome.setVisible(false);
      welcome.setHorizontalAlignment(JLabel.CENTER);
      welcome.setFont(new Font(null, Font.BOLD, 20));
      welcome.setBounds(frame.getWidth()/2, 420, 250, 45);

      cancel = new JButton("Cancel");
      cancel.setBackground(Color.BLACK);
      cancel.setForeground(Color.WHITE);
      cancel.setFocusable(false);
      cancel.setFont(new Font(null, Font.BOLD, 20));
      cancel.setOpaque(true);
      cancel.setBounds(390, 500, 100, 45);
      cancel.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
          // TODO Auto-generated method stub
          System.exit(0);
        }
      });
      cancel.addMouseListener(new MouseListener(){
        @Override
        public void mouseClicked(MouseEvent e) {}

        @Override
        public void mousePressed(MouseEvent e) {}

        @Override
        public void mouseReleased(MouseEvent e) {}

        @Override
        public void mouseEntered(MouseEvent e) {
          // TODO Auto-generated method stub
          soundEffect();
        }

        @Override
        public void mouseExited(MouseEvent e) {}
      });

      start = new JButton("Start");
      start.setBounds(150, 500, 100, 45);
      start.setBackground(Color.BLACK);
      start.setForeground(Color.WHITE);
      start.setFocusable(false);
      start.setFont(new Font(null, Font.BOLD, 20));
      start.setOpaque(true);
      start.setEnabled(false);
      start.addActionListener(new ActionListener(){
        @Override
        public void actionPerformed(ActionEvent e) {
          // TODO Auto-generated method stub
          new Frame(name.getText());
        }
      });
      start.addMouseListener(new MouseListener(){
        @Override
        public void mouseClicked(MouseEvent e) {}

        @Override
        public void mousePressed(MouseEvent e) {}

        @Override
        public void mouseReleased(MouseEvent e) {}

        @Override
        public void mouseEntered(MouseEvent e) {
          // TODO Auto-generated method stub
          soundEffect();
        }

        @Override
        public void mouseExited(MouseEvent e) {}
      });

      JButton showRecord = new JButton("Board");
      showRecord.setBackground(Color.BLACK);
      showRecord.setForeground(Color.WHITE);
      showRecord.setFocusable(false);
      showRecord.setFont(new Font(null, Font.BOLD, 20));
      showRecord.setOpaque(true);
      showRecord.setBounds(270, 500, 100, 45);
      showRecord.addActionListener(new ActionListener(){
        @Override
        public void actionPerformed(ActionEvent e) {
          // TODO Auto-generated method stub
          receivedFile();
        }
      });
      showRecord.addMouseListener(new MouseListener(){
        @Override
        public void mouseClicked(MouseEvent e) {}

        @Override
        public void mousePressed(MouseEvent e) {}

        @Override
        public void mouseReleased(MouseEvent e) {}

        @Override
        public void mouseEntered(MouseEvent e) {
          // TODO Auto-generated method stub
          soundEffect();
        }

        @Override
        public void mouseExited(MouseEvent e) {}
      });

      frame.setLayout(null);
      frame.add(showPass);
      frame.add(title);
      frame.add(namelb);
      frame.add(name);
      frame.add(passlb);
      frame.add(pass);
      frame.add(submit);
      frame.add(welcome);
      frame.add(start);
      frame.add(showRecord);
      frame.add(cancel);
      frame.setResizable(false);
      frame.setSize(650, 600);
      frame.setVisible(true);
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.setLocation(500, 100);

    } catch (Exception e) {
      // TODO: handle exception
      System.out.println(e.getMessage());
    }
  }

  // sound
  public void soundEffect() {
    try {
      sound = new File("D:\\JAVA\\client\\sound_game_1.wav");
      AudioInputStream audio = AudioSystem.getAudioInputStream(sound);
      Clip clip = AudioSystem.getClip();
      clip.open(audio);
      clip.start();
    } catch (Exception e) {
      //TODO: handle exception
      e.printStackTrace();
    }
  }

  // encryption password
  public String encryptString(String input) throws NoSuchAlgorithmException {
    MessageDigest md = MessageDigest.getInstance("MD5");
    byte[] messageDigest = md.digest(input.getBytes());
    BigInteger bigInt = new BigInteger(1, messageDigest);
    return bigInt.toString(16); // base 10 2 8 16
  }

  public void receivedFile() {
    try {
      Socket s = new Socket("localhost", 12345);
      // send command
      ObjectOutputStream outputObject = new ObjectOutputStream(s.getOutputStream());
      ArrayList<String> cmd = new ArrayList<String>();
      String msg = "show";
      cmd.add(msg);
      outputObject.writeObject(cmd);
      ObjectInputStream in = new ObjectInputStream(s.getInputStream());
      int fileNameLength = Integer.parseInt(in.readUTF());
      System.out.println(fileNameLength);
      byte[] fileNameBytes = new byte[fileNameLength];
      System.out.println(fileNameBytes);
      // 
      if (fileNameLength > 0) {
        in.readFully(fileNameBytes, 0, fileNameBytes.length);
        fileName = new String(fileNameBytes);
        System.out.println(fileName);
        int fileContentLength = Integer.parseInt(in.readUTF());
        if(fileContentLength > 0)
        {
          byte[] fileContentBytes = new byte[fileContentLength];
          in.readFully(fileContentBytes, 0, fileContentLength);
          if(getFileExtension(fileName).equalsIgnoreCase("txt"))
          {
            System.out.println("txt");
          }
          else {
            new Table(fileName);
          }
        }
      }
    } catch (Exception e) {
      //TODO: handle exception
      e.printStackTrace();
    }
  }

  public String getFileExtension(String fileName) {
    int i = fileName.lastIndexOf('.');

    if (i > 0) {
      return fileName.substring(i + 1);
    } else {
      return "Nope";
    }
  }

  public void checkLogin(String username, String hash) {
    try {
      Socket socket = new Socket("localhost", 12345);
      ObjectOutputStream objectOutput = new ObjectOutputStream(socket.getOutputStream());
      ArrayList<String> listData = new ArrayList<String>();
      listData.add("check");
      listData.add(username);
      listData.add(encryptString(hash));
      objectOutput.writeObject(listData);
      ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
      Object ob = in.readObject();
      String res = (String) ob;
      if (res.equals("yes")) {
        start.setEnabled(true);
        System.out.println(res);
      }
      if (res.equals("no")) {
        System.out.println(res);
      }
    } catch (Exception e) {
      // TODO: handle exception
      System.out.println(sql);
      System.out.println(e.getMessage());
    }
  }

  public void showMessage(String message) {
    JOptionPane.showMessageDialog(null, message);
  }

  public static void main(String[] args) {
    new Main();
  }

}
