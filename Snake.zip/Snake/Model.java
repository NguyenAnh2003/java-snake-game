package client;

import org.w3c.dom.*;
import javax.xml.parsers.*;

import java.util.*;
import javax.swing.table.*;

public class Model extends AbstractTableModel {
	Vector data;
	Vector columns;
	String[] title = {
			"Name",
			"Point"
	};

	public Model(String file) {
		try {
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
			Document doc = db.parse(file);

			NodeList nl = doc.getElementsByTagName("name");
			NodeList n2 = doc.getElementsByTagName("point");
			NodeList listOfPersons = doc.getElementsByTagName("members");
			String data1 = "", data2 = "";
			data = new Vector();
			columns = new Vector();
			for (int i = 0; i < listOfPersons.getLength(); i++) {
				data1 = nl.item(i).getFirstChild().getNodeValue();
				data2 = n2.item(i).getFirstChild().getNodeValue();
				String line = data1 + " " + data2;
				StringTokenizer st2 = new StringTokenizer(line, " ");
				while (st2.hasMoreTokens())
					data.addElement(st2.nextToken());
			}
			// add columns
			for(int i = 0; i<1; i++)
			{
				Node root = listOfPersons.item(i);
				if(root.getNodeType() == Element.ELEMENT_NODE)
				{	
					NodeList node = root.getChildNodes();
					for(int j = 0; j<node.getLength(); j++)
					{
						Node column = node.item(j);
						if(column.getNodeType() == Element.ELEMENT_NODE)
						{
							columns.add("");
						}
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Override
	public String getColumnName(int column) {
		return title[column];
	}

	public int getRowCount() {
		return data.size() / getColumnCount();
	}

	public int getColumnCount() {
		return columns.size();
	}

	public Object getValueAt(int rowIndex, int columnIndex) {
		return (String) data.elementAt((rowIndex * getColumnCount())
				+ columnIndex);
	}

}